<?php namespace Ville\Storage\User;
 
interface UserRepository {
   
 
}