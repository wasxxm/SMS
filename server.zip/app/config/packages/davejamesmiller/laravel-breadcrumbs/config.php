<?php

return array(
    'view' => '_partials.breadcrumbs',
);
