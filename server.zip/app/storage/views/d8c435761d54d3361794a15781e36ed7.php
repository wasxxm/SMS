<?php $__env->startSection('the_title'); ?>
<title>Create New Company</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body_title'); ?>
<h3 class="page-title"> Create New Company </h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<ul class="page-breadcrumb">
  <li> <i class="fa fa-home"></i> <?php echo link_to('/', 'Dashboard');; ?> <i class="fa fa-angle-right"></i> </li>
  <li> <?php echo link_to('companies', 'Companies'); ?> <i class="fa fa-angle-right"></i> </li>
  <li> Create New Company </li>
</ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-12"> 
  <!-- BEGIN EXAMPLE TABLE PORTLET-->
  <div class="portlet box grey-cascade">
    <div class="portlet-title">
      <div class="caption"> Enter Company Details </div>
    </div>
    <div class="portlet-body"> <?php if(isset($company) && $company->count()): ?>
      <?php echo Form::model($company, array('route' => array('companies.update', $company->company_id), 'files' => true, 'method' => 'PUT')); ?>

      <?php else: ?>
      <?php echo Form::open(array('route' => 'companies.store', 'files' => true)); ?>

      <?php endif; ?>
      <table class="table table-striped table-bordered table-hover" id="create_edit_company">
        <tbody>
          <tr>
            <td><?php echo Form::label('company_name', 'Company Name: '); ?></td>
            <td><?php echo Form::text('company_name', '', array('class' => 'text')); ?> <?php echo $errors->first('company_name', '<span class="error">:message</span>'); ?></td>
          </tr>
        </tbody>
      </table>
      <div> <?php echo Form::label('company_name', 'Company Name: '); ?> <br>
        <?php echo Form::text('company_name'); ?>

        <?php echo $errors->first('company_name', '<span class="error">:message</span>'); ?> </div>
      <div> <?php echo Form::label('company_reg_no', 'Company Registration Number: '); ?> <br>
        <?php echo Form::text('company_reg_no'); ?>

        <?php echo $errors->first('company_reg_no', '<span class="error">:message</span>'); ?> </div>
      <div> <?php echo Form::label('company_country', 'Company Country: '); ?> <br>
        <?php echo Form::select('company_country', array_combine(DB::table('countries')->lists('name'),DB::table('countries')->lists('name'))); ?>

        <?php echo $errors->first('company_country', '<span class="error">:message</span>'); ?> </div>
      <div> <?php echo Form::label('company_city', 'Company City: '); ?> <br>
        <?php echo Form::text('company_city'); ?>

        <?php echo $errors->first('company_city', '<span class="error">:message</span>'); ?> </div>
      <div> <?php echo Form::label('company_state', 'Company State: '); ?> <br>
        <?php echo Form::text('company_state'); ?>

        <?php echo $errors->first('company_state', '<span class="error">:message</span>'); ?> </div>
      <div> <?php echo Form::label('company_address', 'Company Address: '); ?> <br>
        <?php echo Form::textarea('company_address', null, ['size' => '40x3']); ?>

        <?php echo $errors->first('company_address', '<span class="error">:message</span>'); ?> </div>
      <div> <?php echo Form::label('company_phone', 'Company Phone: '); ?> <br>
        <?php echo Form::text('company_phone'); ?>

        <?php echo $errors->first('company_phone', '<span class="error">:message</span>'); ?> </div>
      <div> <?php echo Form::label('company_website', 'Company Web Site: '); ?> <br>
        <?php echo Form::text('company_website'); ?>

        <?php echo $errors->first('company_website', '<span class="error">:message</span>'); ?> </div>
      <div> <?php echo Form::label('company_email', 'Company Email: '); ?> <br>
        <?php echo Form::text('company_email'); ?>

        <?php echo $errors->first('company_email', '<span class="error">:message</span>'); ?> </div>
      <div> <?php echo Form::label('company_ntn', 'Company NTN: '); ?> <br>
        <?php echo Form::text('company_ntn'); ?>

        <?php echo $errors->first('company_ntn', '<span class="error">:message</span>'); ?> </div>
      <div> <?php echo Form::label('company_vat', 'Company VAT: '); ?> <br>
        <?php echo Form::text('company_vat'); ?>

        <?php echo $errors->first('company_vat', '<span class="error">:message</span>'); ?> </div>
      <div> <?php echo Form::label('company_currency_code', 'Company Currency Code: '); ?> <br>
        <?php echo Form::text('company_currency_code', 'USD'); ?>

        <?php echo $errors->first('company_currency_code', '<span class="error">:message</span>'); ?> </div>
      <div> <?php echo Form::label('company_users_limit', 'Company Users Limit: '); ?> <br>
        <?php echo Form::number('company_users_limit', 10); ?>

        <?php echo $errors->first('company_users_limit', '<span class="error">:message</span>'); ?> </div>
      <div> <?php echo Form::label('company_logo_uri', 'Company Logo: '); ?> <br>
        <?php echo Form::file('company_logo_uri'); ?>

        <?php echo $errors->first('company_logo_uri', '<span class="error">:message</span>'); ?> </div>
      <br>
      <?php if(isset($company) && $company->count()): ?>
      <div><?php echo Form::submit('Update Company'); ?></div>
      <?php else: ?>
      <div><?php echo Form::submit('Create Company'); ?></div>
      <?php endif; ?>
      
      <?php echo Form::close(); ?> </div>
  </div>
  <!-- END EXAMPLE TABLE PORTLET-->
  <div class="portlet light bordered">
    <div class="portlet-title">
      <div class="caption"> <span class="caption-subject  bold uppercase">Enter Company Details</span> <span class="caption-helper">fields marked with * are required</span> </div>
      
    </div>
    <div class="portlet-body form"> 
      <!-- BEGIN FORM-->
      <?php if(isset($company) && $company->count()): ?>
      <?php echo Form::model($company, array('route' => array('companies.update', $company->company_id), 'files' => true, 'method' => 'PUT', 'class' => 'form-horizontal')); ?>

      <?php else: ?>
      <?php echo Form::open(array('route' => 'companies.store', 'files' => true, , 'class' => 'form-horizontal')); ?>

      <?php endif; ?>
        <div class="form-body">
          <div class="form-group">
            <?php echo Form::label('company_name', 'Company Name: ', array('class' => 'col-md-3 control-label')); ?>

            <div class="col-md-4">
              <?php echo Form::text('company_name', '', array('class' => 'form-control')); ?> </div>
          </div>
          <div class="form-group">
            <label class="col-md-3 control-label">Email Address</label>
            <div class="col-md-4">
              <div class="input-group"> <span class="input-group-addon"> <i class="fa fa-envelope"></i> </span>
                <input type="email" class="form-control" placeholder="Email Address">
              </div>
            </div>
          </div>
          <div class="form-group">
            <label class="col-md-3 control-label">Password</label>
            <div class="col-md-4">
              <div class="input-group">
                <input type="password" class="form-control" placeholder="Password">
                <span class="input-group-addon"> <i class="fa fa-user"></i> </span> </div>
            </div>
          </div>
          <div class="form-group">
            <label class="col-md-3 control-label">Left Icon</label>
            <div class="col-md-4">
              <div class="input-icon"> <i class="fa fa-bell-o"></i>
                <input type="text" class="form-control" placeholder="Left icon">
              </div>
            </div>
          </div>
          <div class="form-group">
            <label class="col-md-3 control-label">Right Icon</label>
            <div class="col-md-4">
              <div class="input-icon right"> <i class="fa fa-microphone"></i>
                <input type="text" class="form-control" placeholder="Right icon">
              </div>
            </div>
          </div>
          <div class="form-group">
            <label class="col-md-3 control-label">Input With Spinner</label>
            <div class="col-md-4">
              <input type="password" class="form-control spinner" placeholder="Password">
            </div>
          </div>
          <div class="form-group last">
            <label class="col-md-3 control-label">Static Control</label>
            <div class="col-md-4">
              <p class="form-control-static"> email@example.com </p>
            </div>
          </div>
        </div>
        <div class="form-actions">
          <div class="row">
            <div class="col-md-offset-3 col-md-9">
              <button type="submit" class="btn green">Submit</button>
              <button type="button" class="btn default">Cancel</button>
            </div>
          </div>
        </div>
      <?php echo Form::close(); ?>

      <!-- END FORM--> 
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>